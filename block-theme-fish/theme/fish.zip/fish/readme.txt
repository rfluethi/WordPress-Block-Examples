== Fish ==

Contributors: Rico F. Lüthi
Requires at least: 6.8
Tested up to: 6.8
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This theme is a child theme customization of the “Twenty Twenty-Five” theme. It was created for training purposes and demonstrates how a base theme can be modified using a child theme approach.


== Changelog ==

= 1.0.0 =
* Initial release


== Copyright ==

Fish WordPress Theme, (C) 2025 Rico F. Lüthi
Fish is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Fish is a child theme of Twenty Twenty-Five (https://wordpress.org/themes/twentytwentyfive/), (C) the WordPress team, [GPLv2 or later](http://www.gnu.org/licenses/gpl-2.0.html)

